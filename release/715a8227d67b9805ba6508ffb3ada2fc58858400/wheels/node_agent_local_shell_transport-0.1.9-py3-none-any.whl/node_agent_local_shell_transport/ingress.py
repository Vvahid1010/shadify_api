"""Uvicorn's real TLS connection supplies typed evidence before app dispatch."""

import hashlib
from dataclasses import dataclass
from types import MappingProxyType

from uvicorn.protocols.http.h11_impl import H11Protocol

from .transport import _digest, _identity

_EVIDENCE_KEY = "node_agent.local_tls_peer"


@dataclass(frozen=True)
class PeerBinding:
    connection_id: str
    node_id: str
    app_instance_id: str
    certificate_sha256: str

    def __post_init__(self):
        for value in (self.connection_id, self.node_id, self.app_instance_id):
            _identity(value)
        _digest(self.certificate_sha256)


@dataclass(frozen=True)
class _PeerEvidence:
    binding: PeerBinding


def trusted_ingress(scope):
    from app_security_shell.transport import TrustedPeer

    evidence = scope.get(_EVIDENCE_KEY)
    if type(evidence) is not _PeerEvidence:
        return None
    binding = evidence.binding
    return TrustedPeer(binding.connection_id, binding.node_id, binding.app_instance_id)


def ingress_protocol(peers, health_paths=()):
    """Return one H11 class bound to an immutable, certificate-pinned local map.

    Launch with TLS CERT_OPTIONAL + the dedicated CA and ws='none'. Missing client
    certificates permit only exact GET/HEAD health paths. Unknown certificates
    never permit any route, even health. Identity cannot arrive in HTTP headers.
    """
    peers = tuple(peers)
    if any(type(peer) is not PeerBinding for peer in peers):
        raise ValueError("invalid_peer_binding")
    indexed = {peer.certificate_sha256: peer for peer in peers}
    if len(indexed) != len(peers):
        raise ValueError("duplicate_peer_certificate")
    indexed = MappingProxyType(indexed)
    health_paths = frozenset(health_paths)
    if any(
        type(path) is not str
        or not path.startswith("/")
        or "?" in path
        or "#" in path
        or "%" in path
        or not path.isascii()
        for path in health_paths
    ):
        raise ValueError("invalid_health_path")

    class LocalTLSH11Protocol(H11Protocol):
        def connection_made(self, transport):
            super().connection_made(transport)
            tls = transport.get_extra_info("ssl_object")
            certificate = tls.getpeercert(binary_form=True) if tls else None
            peer = indexed.get(hashlib.sha256(certificate).hexdigest()) if certificate else None
            # Bind this connection's application only after Uvicorn initialized it.
            app = self.app

            async def admitted(scope, receive, send):
                if scope["type"] != "http":
                    return await app(scope, receive, send)
                scope = dict(scope)
                scope.pop(_EVIDENCE_KEY, None)
                health = (
                    tls is not None
                    and certificate is None
                    and scope.get("method") in ("GET", "HEAD")
                    and scope.get("path") in health_paths
                    and scope.get("raw_path") == scope.get("path", "").encode("ascii")
                )
                if peer is None and not health:
                    await send(
                        {
                            "type": "http.response.start",
                            "status": 403,
                            "headers": [(b"content-length", b"0")],
                        }
                    )
                    await send({"type": "http.response.body", "body": b""})
                    return
                if peer is not None:
                    scope[_EVIDENCE_KEY] = _PeerEvidence(peer)
                return await app(scope, receive, send)

            self.app = admitted

    return LocalTLSH11Protocol
