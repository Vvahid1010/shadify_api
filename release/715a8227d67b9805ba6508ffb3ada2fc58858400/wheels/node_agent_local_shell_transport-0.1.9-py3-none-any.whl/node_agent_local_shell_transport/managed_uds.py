"""Fixed managed Nginx Unix hops; peer credentials precede every HTTP exchange.

The app owns these clients. This module never starts Nginx, edits policy, opens
TCP, accepts socket paths from requests or derives peer identity from headers.
"""

import os
import pwd
import socket
import stat
import struct
from dataclasses import dataclass
from pathlib import Path

import httpcore
import httpx
from uvicorn.protocols.http.h11_impl import H11Protocol

from .transport import _ManagedClient, _PinnedStream, _Transport

SENDER_SOCKET = "/run/node-agent-nginx-transport-sender/authentication.sock"
BASE = "http://node-agent-managed.invalid"
_EVIDENCE = "node_agent.managed_nginx_peer"
_HEADERS = (
    b"x-node-agent-transport-id",
    b"x-node-agent-transport-generation",
    b"x-node-agent-sender-node",
    b"x-node-agent-client-serial",
)


def _uid():
    return pwd.getpwnam("node_agent_transport").pw_uid


def _peer(sock):
    if sock is None or sock.family != socket.AF_UNIX:
        raise ValueError("managed_unix_peer_required")
    pid, uid, gid = struct.unpack("3i", sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
    if pid <= 0 or uid != _uid():
        raise ValueError("managed_nginx_peer_required")
    return pid, uid, gid


def _socket_path():
    path = Path(SENDER_SOCKET)
    for parent in path.parents:
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid not in {0, _uid()} or info.st_mode & 0o022:
            raise ValueError("managed_socket_parent")
    info = path.lstat()
    if not stat.S_ISSOCK(info.st_mode) or info.st_uid != _uid() or info.st_mode & 0o007:
        raise ValueError("managed_socket_owner")
    return str(path)


class _UDSStream(_PinnedStream):
    async def start_tls(self, ssl_context, server_hostname=None, timeout=None):  # noqa: ASYNC109
        await self.stream.aclose()
        raise httpcore.ConnectError("managed_local_tls_disabled")


class _Backend(httpcore.AsyncNetworkBackend):
    def __init__(self, owner):
        self.owner, self.backend = owner, httpcore.AnyIOBackend()

    async def connect_tcp(self, *args, **kwargs):
        raise httpcore.ConnectError("managed_tcp_disabled")

    async def connect_unix_socket(self, path, timeout=None, socket_options=None):  # noqa: ASYNC109
        self.owner._require_active()
        if path != SENDER_SOCKET:
            raise httpcore.ConnectError("managed_socket_changed")
        stream = await self.backend.connect_unix_socket(_socket_path(), timeout, socket_options)
        try:
            _peer(stream.get_extra_info("socket"))
            self.owner._require_active()
            return _UDSStream(stream, self.owner)
        except BaseException:
            await stream.aclose()
            raise

    async def sleep(self, seconds):
        await self.backend.sleep(seconds)


class _UDSTransport(_Transport):
    def __init__(self, owner):
        self.owner = owner
        self.pool = httpcore.AsyncConnectionPool(
            network_backend=_Backend(owner),
            uds=SENDER_SOCKET,
            http1=True,
            http2=False,
            retries=0,
            max_connections=8,
            max_keepalive_connections=0,
        )


class ManagedUDSClient:
    def __init__(self, connection, native_binding, *, current):
        if not callable(current) or type(native_binding) is not tuple or len(native_binding) != 6:
            raise ValueError("managed_binding_required")
        self.connection, self.native_binding, self.current = connection, native_binding, current
        self._url, self._active, self.pid = httpx.URL(BASE), True, os.getpid()
        self._transport = self._make_transport()
        self.client = _ManagedClient(
            self,
            self._transport,
            transport=self._transport,
            trust_env=False,
            follow_redirects=False,
            timeout=httpx.Timeout(30),
        )

    def _make_transport(self):
        return _UDSTransport(self)

    def _require_active(self):
        if not self._active or os.getpid() != self.pid or self.current() is not True:
            raise httpx.TransportError("managed_selection_changed")

    def trusted_egress(self, connection, base, client):
        from app_security_shell.transport import TrustedEgress

        try:
            self._require_active()
            if (
                connection != self.connection
                or base != BASE
                or client is not self.client
                or client.is_closed
                or client._transport is not self._transport
                or client._mounts
            ):
                return None
            return TrustedEgress(connection, BASE, *self.native_binding, client)
        except Exception:
            return None

    def revoke(self):
        self._active = False

    async def aclose(self):
        self.revoke()
        await self.client.aclose()


@dataclass(frozen=True)
class _PeerEvidence:
    pid: int
    uid: int
    gid: int
    metadata: tuple[bytes, ...]


def trusted_ingress(
    scope,
    *,
    transport_id,
    generation,
    sender_node_id,
    client_serial,
    connection_id,
    sender_app_instance_id,
):
    from app_security_shell.transport import TrustedPeer

    evidence = scope.get(_EVIDENCE)
    if type(evidence) is not _PeerEvidence or evidence.uid != _uid():
        return None
    expected = tuple(
        str(value).encode("ascii")
        for value in (transport_id, generation, sender_node_id, client_serial)
    )
    if evidence.metadata != expected:
        return None
    return TrustedPeer(connection_id, sender_node_id, sender_app_instance_id)


def ingress_protocol(*, legacy_loopback_carrier=False):
    """Kernel-verified Nginx peer; optional packet-3.4 loopback carrier only."""
    if type(legacy_loopback_carrier) is not bool:
        raise ValueError("invalid_legacy_carrier_option")

    class ManagedH11Protocol(H11Protocol):
        def connection_made(self, transport):
            super().connection_made(transport)
            sock = transport.get_extra_info("socket")
            try:
                peer = _peer(sock)
            except (OSError, ValueError, KeyError):
                peer = None
            legacy_tcp = (
                legacy_loopback_carrier
                and sock is not None
                and sock.family == socket.AF_INET
                and sock.getsockname()[0] == "127.0.0.1"
            )
            app = self.app

            async def admitted(scope, receive, send):
                inner = dict(scope)
                inner.pop(_EVIDENCE, None)
                headers = inner.get("headers", [])
                # Fixed local readiness remains available to the root observer;
                # it never receives trusted peer evidence or a business route.
                health = (
                    inner.get("method") in {"GET", "HEAD"}
                    and inner.get("path") in {"/health", "/health/ready"}
                    and inner.get("raw_path") == inner.get("path", "").encode("ascii")
                    and not inner.get("query_string")
                )
                if health:
                    inner["headers"] = [
                        (name, value)
                        for name, value in headers
                        if not name.startswith(b"x-node-agent-")
                    ]
                    await app(inner, receive, send)
                    return
                # The retained packet-3.4 carrier authenticates its own
                # envelope. It has no native trusted-peer evidence and no
                # access to any other route on the loopback listener.
                if (
                    legacy_tcp
                    and inner.get("method") == "POST"
                    and inner.get("path") == "/api/_managed/envelope"
                    and inner.get("raw_path") == b"/api/_managed/envelope"
                    and not inner.get("query_string")
                    and not any(name.startswith(b"x-node-agent-") for name, _ in headers)
                ):
                    await app(inner, receive, send)
                    return
                values = tuple(
                    [value for name, value in headers if name == key] for key in _HEADERS
                )
                if peer is None or any(len(value) != 1 for value in values):
                    await send(
                        {
                            "type": "http.response.start",
                            "status": 403,
                            "headers": [(b"content-length", b"0")],
                        }
                    )
                    await send({"type": "http.response.body", "body": b""})
                    return
                inner[_EVIDENCE] = _PeerEvidence(*peer, tuple(value[0] for value in values))
                # Uvicorn represents a Unix listener as (socket_path, None).
                # The shell intentionally drops Host before business dispatch;
                # give URL/path validation a fixed local authority instead.
                inner["server"] = ("node-agent-managed.invalid", 80)
                inner["headers"] = [
                    (name, value)
                    for name, value in headers
                    if not name.startswith(b"x-node-agent-")
                ]
                await app(inner, receive, send)

            self.app = admitted

    return ManagedH11Protocol


class ConfiguredSender:
    """Process-owned clients for immutable Credentials config, not a selector file."""

    def __init__(self, binding, document):
        self.binding = binding
        self.local = None
        if type(document) is dict and document.get("profile") == "local_unix_v1":
            from .local_uds import ConfiguredLocalSender

            self.local = ConfiguredLocalSender(document)
            self.channels = {self.local.channel.connection_id: self.local.channel}
            self.clients = self.local.clients
            return
        self.channels = _configured_channels(document, "sender")
        self.clients = {}

    def prepare(self, connection, metadata):
        if self.local is not None:
            return self.local.prepare(connection, metadata)
        if connection not in self.channels or metadata["base_url"] != BASE:
            raise ValueError("configured_channel_mismatch")
        native = metadata["transport_binding"]
        channel = self.channels[connection]
        if (native[0] != channel["sender_node_id"]
                or native[1] != channel["sender_app_instance_id"]
                or native[2] != channel["receiver_node_id"]):
            raise ValueError("configured_sender_identity_mismatch")
        previous = self.clients.get(connection)
        if previous is not None:
            if previous.native_binding != native:
                raise ValueError("configured_policy_changed")
            return
        client = ManagedUDSClient(connection, native, current=lambda: (
            self.clients.get(connection) is client
        ))
        self.clients[connection] = client

    def client_for(self, connection, *, stream=False):
        if self.local is not None:
            return self.local.client_for(connection, stream=stream)
        if stream:
            raise ValueError("managed_stream_not_supported")
        return self.clients[connection].client

    def trusted_egress(self, connection, base, client):
        if self.local is not None:
            return self.local.trusted_egress(connection, base, client)
        selected = self.clients.get(connection)
        return selected.trusted_egress(connection, base, client) if selected else None

    async def aclose(self):
        if self.local is not None:
            return await self.local.aclose()
        clients, self.clients = self.clients, {}
        for client in clients.values():
            await client.aclose()


def _configured_channels(document, role):
    """Validate config-supplied peer metadata; request headers never select it."""
    import re
    from uuid import UUID

    if (type(document) is not dict or set(document) != {"profile", "role", "channels"}
            or document["profile"] != "managed_nginx" or document["role"] != role
            or type(document["channels"]) is not dict or len(document["channels"]) != 1):
        raise ValueError("configured_transport_invalid")
    channels = {}
    for connection, value in document["channels"].items():
        if str(UUID(connection)) != connection or type(value) is not dict or set(value) != {
            "transport_id", "generation", "group_revision", "sender_node_id",
            "receiver_node_id", "client_serial", "sender_app_instance_id",
        }:
            raise ValueError("configured_channel_invalid")
        for name in ("transport_id", "sender_node_id", "receiver_node_id", "sender_app_instance_id"):
            if str(UUID(value[name])) != value[name]:
                raise ValueError("configured_identity_invalid")
        for name in ("generation", "group_revision"):
            if type(value[name]) is not int or not 1 <= value[name] < 2**63:
                raise ValueError("configured_generation_invalid")
        if not re.fullmatch(r"[A-F0-9]{1,40}", value["client_serial"]):
            raise ValueError("configured_serial_invalid")
        channels[connection] = dict(value)
    return channels


def install_configured_receiver(binding, document, policy, *, clock_bounds=None, storage_bounds=None):
    if type(document) is dict and document.get("profile") == "local_unix_v1":
        from .local_uds import install_configured_receiver as install_local_receiver

        return install_local_receiver(binding, document, policy, clock_bounds=clock_bounds,
                                      storage_bounds=storage_bounds)
    channels = _configured_channels(document, "receiver")
    connection, channel = next(iter(channels.items()))
    connections = policy["connections"]
    if len(connections) != 1 or connections[0]["connection_id"] != connection:
        raise ValueError("configured_receiver_connection_mismatch")
    sender = connections[0]["sender"]["identity"]
    recipient = connections[0]["recipient"]["identity"]
    if (recipient != policy["local"] or recipient["node_id"] != channel["receiver_node_id"]
            or recipient["app_id"] != "mizfood_api"
            or sender["node_id"] != channel["sender_node_id"]
            or sender["app_instance_id"] != channel["sender_app_instance_id"]
            or sender["app_id"] != "authentication"):
        raise ValueError("configured_receiver_identity_mismatch")

    def ingress(scope):
        return trusted_ingress(scope, connection_id=connection, **{
            key: channel[key] for key in (
                "transport_id", "generation", "sender_node_id", "client_serial",
                "sender_app_instance_id",
            )
        })

    binding.install_integration(trusted_ingress=ingress, clock_bounds=clock_bounds, storage_bounds=storage_bounds)
