#!/usr/bin/env python3
"""Read-only, value-blind WSL installation inventory. No imports of live apps."""
import json
import os
from pathlib import Path
import stat

ROOT = Path("/etc/chapary-local/credentials")
APPS = ("authentication", "chapary_api", "mizfood_api", "chapary_trade_api")


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("invalid_configuration")
        result[key] = value
    return result


def _read(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as file:
        if not stat.S_ISREG(os.fstat(file.fileno()).st_mode):
            raise ValueError("invalid_configuration")
        raw = file.read(4 * 1024 * 1024 + 1)
    if len(raw) > 4 * 1024 * 1024:
        raise ValueError("invalid_configuration")
    data = json.loads(raw, object_pairs_hook=_unique)
    if type(data) is not dict:
        raise ValueError("invalid_configuration")
    return data


def report(root=ROOT):
    output = {}
    for app in APPS:
        directory = root / app
        candidates = ("runtime.json",) if app == "chapary_trade_api" else (app + ".config.json", "config.json")
        row = {"config": "unavailable", "shell_present": False, "transport_present": False}
        try:
            if directory.is_symlink():
                raise ValueError("invalid_directory")
            selected = next((directory / name for name in candidates if (directory / name).exists()), None)
            if selected is None:
                raise ValueError("missing_configuration")
            config = _read(selected)
            row["config"] = "readable"
            row["shell_present"] = "app_security" in config
            row["transport_present"] = (directory / "app_security.transport.json").is_file()
            if app == "mizfood_api":
                profile = _read(directory / "app_profile.json")
                row["deployment_boundary"] = "managed_requires_separate_reconciliation" if (
                    "managed" in config or "deployment_mode" in profile) else "legacy_common_shell_eligible"
            if app == "authentication":
                targets = config.get("proxy", {}).get("apps", {})
                row["required_proxy_targets_present"] = all(name in targets for name in APPS[1:])
            if app == "chapary_trade_api":
                row["sim_only_configuration"] = (
                    config.get("migration", {}).get("runtime_enabled") is True
                    and config.get("migration", {}).get("allow_live_trading") is False
                    and config.get("tradestation", {}).get("environment") == "SIM"
                    and config.get("tradestation", {}).get("allow_live_trading") is False
                    and config.get("internal_execution", {}).get("live_execution_enabled") is False
                    and config.get("admin", {}).get("enabled") is False)
        except Exception:
            row["config"] = "unavailable_or_invalid"
        output[app] = row
    return output


def main():
    if os.geteuid() != 0:
        raise SystemExit("ROOT_REQUIRED: fixed read-only local configuration check")
    print(json.dumps({"operation": "read_only_wsl_shell_preflight", "applications": report()}, indent=2))


if __name__ == "__main__":
    main()
