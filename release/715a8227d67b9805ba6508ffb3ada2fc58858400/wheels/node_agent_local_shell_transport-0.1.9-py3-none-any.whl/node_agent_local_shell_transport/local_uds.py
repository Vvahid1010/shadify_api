"""Fixed direct Authentication → Shadify Unix channel.

Inputs come from an app's protected immutable configuration. No path, account,
listener or credential can be selected by a request; this module provisions
nothing. The retained managed Nginx transport remains a separate profile.
"""

import grp
import pwd
import re
import socket
import stat
import struct
from dataclasses import dataclass
from pathlib import Path
from uuid import UUID

import httpcore
from uvicorn.protocols.http.h11_impl import H11Protocol

from .managed_uds import BASE as BASE
from .managed_uds import ManagedUDSClient, _UDSStream
from .transport import _Transport

SOCKET = "/run/node-agent-shadify-api/receiver.sock"
SENDER_USER = "na-authentication"
RECEIVER_USER = "na-shadify-api"
LOCAL_GROUP = "node_shadify_api_local"
_EVIDENCE = "node_agent.local_shadify_peer"
_HEADERS = (
    b"x-node-agent-local-connection",
    b"x-node-agent-local-generation",
    b"x-node-agent-local-record",
    b"x-node-agent-local-policy-revision",
    b"x-node-agent-local-policy-digest",
)


@dataclass(frozen=True)
class LocalUnixBinding:
    connection_id: str
    node_id: str
    sender_app_instance_id: str
    recipient_app_instance_id: str
    generation: int
    record_sha256: str
    policy_revision: int
    policy_digest: str

    def __post_init__(self):
        for value in (self.connection_id, self.node_id, self.sender_app_instance_id,
                      self.recipient_app_instance_id):
            if type(value) is not str or str(UUID(value)) != value:
                raise ValueError("local_unix_identity_invalid")
        if self.sender_app_instance_id == self.recipient_app_instance_id:
            raise ValueError("local_unix_distinct_apps_required")
        for value in (self.generation, self.policy_revision):
            if type(value) is not int or not 1 <= value < 2**63:
                raise ValueError("local_unix_revision_invalid")
        for value in (self.record_sha256, self.policy_digest):
            if type(value) is not str or not re.fullmatch(r"[a-f0-9]{64}", value):
                raise ValueError("local_unix_commitment_invalid")

    @property
    def native_binding(self):
        return (self.node_id, self.sender_app_instance_id, self.node_id,
                self.recipient_app_instance_id, self.policy_revision, self.policy_digest)

    @property
    def metadata(self):
        return tuple(str(value).encode("ascii") for value in (
            self.connection_id, self.generation, self.record_sha256,
            self.policy_revision, self.policy_digest,
        ))


def _peer(sock, account):
    if sock is None or sock.family != socket.AF_UNIX:
        raise ValueError("local_unix_peer_required")
    pid, uid, gid = struct.unpack("3i", sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
    expected = pwd.getpwnam(account).pw_uid
    if expected <= 0 or pid <= 0 or uid != expected:
        raise ValueError("local_unix_peer_identity_mismatch")
    return pid, uid, gid


def _socket_path():
    receiver = pwd.getpwnam(RECEIVER_USER).pw_uid
    if receiver <= 0:
        raise ValueError("local_unix_receiver_identity_invalid")
    group = grp.getgrnam(LOCAL_GROUP).gr_gid
    if group <= 0:
        raise ValueError("local_unix_group_invalid")
    path = Path(SOCKET)
    for parent in path.parents:
        info = parent.lstat()
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid not in {0, receiver}
                or info.st_mode & 0o022):
            raise ValueError("local_unix_socket_parent_invalid")
    parent = path.parent.lstat()
    if ((parent.st_uid, parent.st_gid, stat.S_IMODE(parent.st_mode))
            != (receiver, group, 0o750)):
        raise ValueError("local_unix_runtime_owner_invalid")
    info = path.lstat()
    if (not stat.S_ISSOCK(info.st_mode) or (info.st_uid, info.st_gid) != (receiver, group)
            or stat.S_IMODE(info.st_mode) != 0o660):
        raise ValueError("local_unix_socket_owner_invalid")
    return str(path)


class _Backend(httpcore.AsyncNetworkBackend):
    def __init__(self, owner):
        self.owner, self.backend = owner, httpcore.AnyIOBackend()

    async def connect_tcp(self, *args, **kwargs):
        raise httpcore.ConnectError("local_unix_tcp_disabled")

    async def connect_unix_socket(self, path, timeout=None, socket_options=None):  # noqa: ASYNC109
        self.owner._require_active()
        if path != SOCKET:
            raise httpcore.ConnectError("local_unix_socket_changed")
        stream = await self.backend.connect_unix_socket(_socket_path(), timeout, socket_options)
        try:
            _peer(stream.get_extra_info("socket"), RECEIVER_USER)
            self.owner._require_active()
            return _UDSStream(stream, self.owner)
        except BaseException:
            await stream.aclose()
            raise

    async def sleep(self, seconds):
        await self.backend.sleep(seconds)


class _LocalTransport(_Transport):
    def __init__(self, owner):
        self.owner = owner
        self.pool = httpcore.AsyncConnectionPool(
            network_backend=_Backend(owner), uds=SOCKET, http1=True, http2=False,
            retries=0, max_connections=8, max_keepalive_connections=0,
        )

    async def handle_async_request(self, request):
        if any(name.startswith(b"x-node-agent-") for name, _ in request.headers.raw):
            raise httpcore.ConnectError("local_unix_caller_metadata_denied")
        # Supply the protected channel commitments in the enforcing transport.
        # Request data never chooses identity, record, generation or policy.
        for name, value in zip(_HEADERS, self.owner.binding.metadata, strict=True):
            request.headers[name.decode("ascii")] = value.decode("ascii")
        return await super().handle_async_request(request)


class LocalUDSClient(ManagedUDSClient):
    def __init__(self, binding, *, current):
        if type(binding) is not LocalUnixBinding:
            raise ValueError("local_unix_binding_required")
        self.binding = binding
        super().__init__(binding.connection_id, binding.native_binding, current=current)

    def _make_transport(self):
        return _LocalTransport(self)


@dataclass(frozen=True)
class _PeerEvidence:
    pid: int
    uid: int
    gid: int
    binding: LocalUnixBinding


def trusted_ingress(scope, binding):
    from app_security_shell.transport import TrustedPeer

    evidence = scope.get(_EVIDENCE)
    if (type(binding) is not LocalUnixBinding or type(evidence) is not _PeerEvidence
            or evidence.binding != binding
            or evidence.uid != pwd.getpwnam(SENDER_USER).pw_uid):
        return None
    return TrustedPeer(binding.connection_id, binding.node_id, binding.sender_app_instance_id)


def ingress_protocol(binding, *, current):
    if type(binding) is not LocalUnixBinding or not callable(current):
        raise ValueError("local_unix_binding_required")

    class LocalH11Protocol(H11Protocol):
        def connection_made(self, transport):
            super().connection_made(transport)
            try:
                peer = _peer(transport.get_extra_info("socket"), SENDER_USER)
            except (OSError, ValueError, KeyError):
                peer = None
            app = self.app

            async def admitted(scope, receive, send):
                inner = dict(scope)
                inner.pop(_EVIDENCE, None)
                headers = inner.get("headers", [])
                inner["headers"] = [(name, value) for name, value in headers
                                    if not name.startswith(b"x-node-agent-")]
                health = (inner.get("method") in {"GET", "HEAD"}
                          and inner.get("path") in {"/health", "/health/ready"}
                          and inner.get("raw_path") == inner.get("path", "").encode("ascii")
                          and not inner.get("query_string"))
                if health:
                    await app(inner, receive, send)
                    return
                values = tuple([value for name, value in headers if name == key]
                               for key in _HEADERS)
                if (peer is None or peer[1] != pwd.getpwnam(SENDER_USER).pw_uid
                        or current() is not True
                        or any(len(value) != 1 for value in values)
                        or tuple(value[0] for value in values) != binding.metadata):
                    await send({"type": "http.response.start", "status": 403,
                                "headers": [(b"content-length", b"0")]})
                    await send({"type": "http.response.body", "body": b""})
                    return
                inner[_EVIDENCE] = _PeerEvidence(*peer, binding)
                inner["server"] = ("node-agent-managed.invalid", 80)
                await app(inner, receive, send)

            self.app = admitted

    return LocalH11Protocol


def configured_channel(document, role):
    """One fixed app pair, from protected config; never a request selector."""
    from dataclasses import fields

    if (type(document) is not dict or set(document) != {"profile", "role", "channels"}
            or document["profile"] != "local_unix_v1" or document["role"] != role
            or type(document["channels"]) is not dict or len(document["channels"]) != 1):
        raise ValueError("configured_local_transport_invalid")
    connection, value = next(iter(document["channels"].items()))
    expected = {field.name for field in fields(LocalUnixBinding)} - {"connection_id"}
    if type(value) is not dict or set(value) != expected:
        raise ValueError("configured_local_channel_invalid")
    return LocalUnixBinding(connection_id=connection, **value)


class ConfiguredLocalSender:
    def __init__(self, document):
        self.channel = configured_channel(document, "sender")
        self.clients = {}

    def prepare(self, connection, metadata):
        channel = self.channel
        if (connection != channel.connection_id or metadata["base_url"] != BASE
                or metadata["transport_binding"] != channel.native_binding):
            raise ValueError("configured_local_sender_binding_mismatch")
        previous = self.clients.get(connection)
        if previous is not None:
            if previous.native_binding != channel.native_binding:
                raise ValueError("configured_policy_changed")
            return
        client = LocalUDSClient(channel, current=lambda: self.clients.get(connection) is client)
        self.clients[connection] = client

    def client_for(self, connection, *, stream=False):
        if type(stream) is not bool or stream:
            raise ValueError("managed_stream_not_supported")
        return self.clients[connection].client

    def trusted_egress(self, connection, base, client):
        selected = self.clients.get(connection)
        return selected.trusted_egress(connection, base, client) if selected else None

    async def aclose(self):
        clients, self.clients = self.clients, {}
        for client in clients.values():
            await client.aclose()


def install_configured_receiver(binding, document, policy, *, clock_bounds, storage_bounds):
    """Bind the exact Shadify receiver to real transport and supplied bounds.

    Returns the immutable channel for the app-owned Uvicorn protocol factory.
    No listener, application service, key or default-healthy bounds are created.
    """
    if not callable(clock_bounds) or not callable(storage_bounds):
        raise ValueError("configured_local_bounds_required")
    channel = configured_channel(document, "receiver")
    connections = policy["connections"]
    if (len(connections) != 1 or connections[0]["connection_id"] != channel.connection_id
            or connections[0]["policy_revision"] != channel.policy_revision):
        raise ValueError("configured_local_receiver_connection_mismatch")
    sender = connections[0]["sender"]["identity"]
    recipient = connections[0]["recipient"]["identity"]
    if (recipient != policy["local"] or recipient["app_id"] != "shadify_api"
            or recipient["node_id"] != channel.node_id
            or recipient["app_instance_id"] != channel.recipient_app_instance_id
            or sender["app_id"] != "authentication" or sender["node_id"] != channel.node_id
            or sender["app_instance_id"] != channel.sender_app_instance_id):
        raise ValueError("configured_local_receiver_identity_mismatch")

    def ingress(scope):
        return trusted_ingress(scope, channel)

    binding.install_integration(trusted_ingress=ingress, clock_bounds=clock_bounds,
                                storage_bounds=storage_bounds)
    return channel
