"""App-side reader of root's short-lived managed clock/replay health leases.

No root observer, credential access or Node Agent service dependency is imported.
"""

import time

LEASE_NS = 10_000_000_000
MAX_ERROR_NS = 500_000_000
MAX_STEP_NS = 100_000_000
BINDINGS = (
    "node_id",
    "app_id",
    "app_instance_id",
    "node_boot_id",
    "app_invocation_id",
    "redis_run_id",
    "redis_invocation_id",
    "resource_revision",
    "resource_sha256",
)


def boottime_ns():
    # Includes suspend; stale evidence cannot become fresh after host resume.
    return time.clock_gettime_ns(time.CLOCK_BOOTTIME)


class ClockContinuity:
    """Kernel clock-step latch, including a forward/back step between samples."""

    def __init__(self):
        import os
        from threading import RLock

        self.lock = RLock()
        self.blocked_until = 0
        self.os = os
        self.pid = os.getpid()
        self.fd = os.timerfd_create(time.CLOCK_REALTIME, flags=os.TFD_CLOEXEC | os.TFD_NONBLOCK)
        try:
            self.arm()
        except Exception:
            os.close(self.fd)
            self.fd = None
            raise

    def arm(self):
        self.os.timerfd_settime_ns(
            self.fd,
            flags=self.os.TFD_TIMER_ABSTIME | self.os.TFD_TIMER_CANCEL_ON_SET,
            initial=time.time_ns() + 86_400_000_000_000,
        )

    def unchanged(self):
        with self.lock:
            return self._unchanged()

    def _unchanged(self):
        import errno

        if self.fd is None or self.os.getpid() != self.pid:
            return False
        try:
            self.os.read(self.fd, 8)
        except BlockingIOError:
            return boottime_ns() >= self.blocked_until
        except OSError as exc:
            if exc.errno != errno.ECANCELED:
                self.close()
                return False
        self.blocked_until = boottime_ns() + 151_000_000_000
        # Expiry is conservative too. Do not clear a cancellation and report
        # healthy in the same call; RedisReplayStore must first invalidate.
        try:
            self.arm()
        except OSError:
            self.close()
        return False

    def close(self):
        with self.lock:
            if self.fd is not None:
                self.os.close(self.fd)
                self.fd = None


class Bounds:
    """Local public projection reader; never contacts the Node Agent API.

    Apps must install the same instance for both replay predicates. An epoch
    change returns false once, including when no request occurred during a gap.
    """

    def __init__(
        self,
        read,
        *,
        node_id,
        app_id,
        app_instance_id,
        boot_id,
        invocation_id,
        monotonic=boottime_ns,
        wall=time.time_ns,
        clock_unchanged=None,
    ):
        self.read, self.monotonic, self.wall = read, monotonic, wall
        self.expected = dict(
            node_id=node_id,
            app_id=app_id,
            app_instance_id=app_instance_id,
            node_boot_id=boot_id,
            app_invocation_id=invocation_id,
        )
        self.epoch = None
        self.clock_guard = ClockContinuity() if clock_unchanged is None else None
        self.clock_unchanged = clock_unchanged or self.clock_guard.unchanged

    def close(self):
        if self.clock_guard is not None:
            self.clock_guard.close()
        self.epoch = None

    def ready(self):
        try:
            if self.clock_unchanged() is not True:
                raise ValueError()
            value = self.read()
            required = set(BINDINGS) | {
                "schema_version",
                "available",
                "observed_boottime_ns",
                "expires_boottime_ns",
                "observed_wall_ns",
                "clock_error_ns",
                "continuity_epoch",
            }
            if (
                type(value) is not dict
                or set(value) != required
                or type(value["schema_version"]) is not int
                or value["schema_version"] != 1
                or value["available"] is not True
                or any(value[k] != v for k, v in self.expected.items())
            ):
                raise ValueError()
            from uuid import UUID

            epoch = value["continuity_epoch"]
            if type(epoch) is not str or str(UUID(epoch)) != epoch or UUID(epoch).int == 0:
                raise ValueError("shell_health_epoch")
            fields = (
                "observed_boottime_ns",
                "expires_boottime_ns",
                "observed_wall_ns",
                "clock_error_ns",
            )
            if any(type(value[k]) is not int or value[k] < 0 for k in fields):
                raise ValueError()
            now, wall = self.monotonic(), self.wall()
            if (
                value["expires_boottime_ns"] - value["observed_boottime_ns"] != LEASE_NS
                or not value["observed_boottime_ns"] <= now < value["expires_boottime_ns"]
                or value["clock_error_ns"] + MAX_STEP_NS > MAX_ERROR_NS
                or abs((wall - value["observed_wall_ns"]) - (now - value["observed_boottime_ns"]))
                > MAX_STEP_NS
            ):
                raise ValueError()
            if epoch != self.epoch:
                self.epoch = epoch
                return False
            return True
        except Exception:
            self.epoch = None
            return False


def read_health(root, role, *, owner_uid=0):
    """Read only the fixed public lease for this process role, never app secrets."""
    import json
    import os
    import stat

    names = {"api": "health.json", "worker": "health-worker.json"}
    if role not in names:
        raise ValueError("shell_health_role")
    directory = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        parent = os.fstat(directory)
        if parent.st_uid != owner_uid or stat.S_IMODE(parent.st_mode) != 0o750:
            raise ValueError("shell_health_directory")
        fd = os.open(
            names[role],
            os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
            dir_fd=directory,
        )
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            if (
                not stat.S_ISREG(before.st_mode)
                or before.st_uid != owner_uid
                or stat.S_IMODE(before.st_mode) != 0o640
                or before.st_nlink != 1
                or not 0 < before.st_size <= 16384
            ):
                raise ValueError("shell_health_file")
            raw = stream.read(16385)
            after = os.fstat(stream.fileno())
            if len(raw) != before.st_size or (before.st_ctime_ns, before.st_mtime_ns) != (
                after.st_ctime_ns,
                after.st_mtime_ns,
            ):
                raise ValueError("shell_health_changed")

        def unique(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError("shell_health_duplicate")
                result[key] = value
            return result

        value = json.loads(raw, object_pairs_hook=unique)
        final = os.stat(names[role], dir_fd=directory, follow_symlinks=False)
        if (final.st_dev, final.st_ino, final.st_ctime_ns) != (
            before.st_dev,
            before.st_ino,
            before.st_ctime_ns,
        ):
            raise ValueError("shell_health_changed")
        return value
    finally:
        os.close(directory)


def process_bounds(root, role, identity, *, owner_uid=0):
    """Bind one managed process to its kernel boot and systemd invocation.

    Missing systemd identity denies shell admission; no fallback lease is made.
    """
    import os
    import re
    from pathlib import Path
    from uuid import UUID

    if role not in {"api", "worker"} or type(identity) is not dict or set(identity) != {
        "node_id", "app_id", "app_instance_id"
    }:
        raise ValueError("shell_process_identity")
    invocation = os.environ.get("INVOCATION_ID", "")
    if not re.fullmatch(r"[0-9a-f]{32}", invocation):
        raise ValueError("shell_process_invocation_required")
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    if str(UUID(boot)) != boot or UUID(boot).int == 0:
        raise ValueError("shell_process_boot_required")
    return Bounds(
        lambda: read_health(root, role, owner_uid=owner_uid),
        **identity,
        boot_id=boot,
        invocation_id=invocation,
    )
