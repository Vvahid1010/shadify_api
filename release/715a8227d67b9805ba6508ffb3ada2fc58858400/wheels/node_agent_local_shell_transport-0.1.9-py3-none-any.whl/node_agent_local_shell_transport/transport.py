"""An owned HTTP client whose real TLS stream is pinned before HTTP can flow."""

# httpcore public backend/stream overrides must preserve their timeout parameter.
# ruff: noqa: ASYNC109

import hashlib
import re
import ssl
from dataclasses import dataclass
from pathlib import Path

import httpcore
import httpx

_SHA256 = re.compile(r"[a-f0-9]{64}")
_FINITE_MAX_CONNECTIONS = 10
_STREAM_MAX_CONNECTIONS = 16


def _digest(value):
    if type(value) is not str or not _SHA256.fullmatch(value):
        raise ValueError("invalid_sha256")


def _identity(value):
    if type(value) is not str or not value or len(value) > 256 or any(ord(c) < 33 for c in value):
        raise ValueError("invalid_identity")


@dataclass(frozen=True)
class ConnectionBinding:
    connection_id: str
    base_url: str
    sender_node_id: str
    sender_app_instance_id: str
    recipient_node_id: str
    recipient_app_instance_id: str
    policy_revision: int
    policy_digest: str
    server_certificate_sha256: str
    client_certificate_sha256: str

    def __post_init__(self):
        for value in (
            self.connection_id,
            self.sender_node_id,
            self.sender_app_instance_id,
            self.recipient_node_id,
            self.recipient_app_instance_id,
        ):
            _identity(value)
        for value in (
            self.policy_digest,
            self.server_certificate_sha256,
            self.client_certificate_sha256,
        ):
            _digest(value)
        if type(self.policy_revision) is not int or self.policy_revision < 1:
            raise ValueError("invalid_revision")
        url = httpx.URL(self.base_url)
        if (
            url.scheme != "https"
            or url.host not in ("localhost", "127.0.0.1", "::1")
            or url.userinfo
            or url.query
            or url.fragment
            or url.path != "/"
            or str(url).rstrip("/") != self.base_url
        ):
            raise ValueError("invalid_local_origin")


class _PinnedStream(httpcore.AsyncNetworkStream):
    def __init__(self, stream, owner):
        self.stream, self.owner = stream, owner

    async def read(self, max_bytes, timeout=None):
        self.owner._require_active()
        return await self.stream.read(max_bytes, timeout)

    async def write(self, buffer, timeout=None):
        self.owner._require_active()
        return await self.stream.write(buffer, timeout)

    async def aclose(self):
        await self.stream.aclose()

    def get_extra_info(self, info):
        return self.stream.get_extra_info(info)

    async def start_tls(self, ssl_context, server_hostname=None, timeout=None):
        self.owner._require_active()
        if ssl_context is not self.owner._ssl or server_hostname != self.owner._url.host:
            await self.stream.aclose()
            raise httpcore.ConnectError("unapproved_tls_parameters")
        secured = None
        try:
            secured = await self.stream.start_tls(ssl_context, server_hostname, timeout)
            tls = secured.get_extra_info("ssl_object")
            cert = tls.getpeercert(binary_form=True) if tls else None
            if (
                not cert
                or hashlib.sha256(cert).hexdigest() != self.owner.binding.server_certificate_sha256
            ):
                raise httpcore.ConnectError("server_certificate_pin_mismatch")
            self.owner._require_active()
            return _PinnedStream(secured, self.owner)
        except BaseException:
            await (secured or self.stream).aclose()
            raise


class _PinnedBackend(httpcore.AsyncNetworkBackend):
    def __init__(self, owner):
        self.owner, self.backend = owner, httpcore.AnyIOBackend()

    async def connect_tcp(self, host, port, timeout=None, local_address=None, socket_options=None):
        self.owner._require_active()
        if host != self.owner._url.host or port != (self.owner._url.port or 443):
            raise httpcore.ConnectError("unapproved_origin")
        # Never resolve a configured local name through ambient DNS.
        address = "127.0.0.1" if host == "localhost" else host
        stream = await self.backend.connect_tcp(
            address, port, timeout, local_address, socket_options
        )
        return _PinnedStream(stream, self.owner)

    async def connect_unix_socket(self, *args, **kwargs):
        raise httpcore.ConnectError("unix_transport_disabled")

    async def sleep(self, seconds):
        await self.backend.sleep(seconds)


class _ResponseStream(httpx.AsyncByteStream):
    def __init__(self, stream):
        self.stream = stream

    async def __aiter__(self):
        try:
            async for part in self.stream:
                yield part
        finally:
            # Release the pool request even when reading is cancelled or the
            # peer closes an incomplete HTTP/1 response.
            await self.aclose()

    async def aclose(self):
        await self.stream.aclose()


class _Transport(httpx.AsyncBaseTransport):
    def __init__(self, owner, *, max_connections, max_keepalive_connections):
        self.owner = owner
        self.pool = httpcore.AsyncConnectionPool(
            ssl_context=owner._ssl,
            network_backend=_PinnedBackend(owner),
            http1=True,
            http2=False,
            retries=0,
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
            keepalive_expiry=5,
        )

    async def handle_async_request(self, request):
        self.owner._require_active()
        url = request.url
        approved = self.owner._url
        if (url.scheme, url.host, url.port) != (approved.scheme, approved.host, approved.port):
            raise httpx.TransportError("unapproved_origin")
        if url.userinfo or "sni_hostname" in request.extensions:
            raise httpx.TransportError("unapproved_request_extensions")
        if request.headers.get("host") != approved.netloc.decode("ascii"):
            raise httpx.TransportError("unapproved_host_header")
        core_request = httpcore.Request(
            method=request.method,
            url=httpcore.URL(
                scheme=url.raw_scheme, host=url.raw_host, port=url.port, target=url.raw_path
            ),
            headers=request.headers.raw,
            content=request.stream,
            extensions=request.extensions,
        )
        response = await self.pool.handle_async_request(core_request)
        return httpx.Response(
            response.status,
            headers=response.headers,
            stream=_ResponseStream(response.stream),
            extensions=response.extensions,
        )

    async def aclose(self):
        self.owner.revoke()
        await self.pool.aclose()


class _ManagedClient(httpx.AsyncClient):
    def __init__(self, owner, owned_transport, **kwargs):
        self._owner, self._owned_transport = owner, owned_transport
        super().__init__(**kwargs)

    async def send(self, request, **kwargs):
        self._owner._require_active()
        if self._transport is not self._owned_transport or self._mounts:
            raise httpx.TransportError("unapproved_client_transport")
        if self.follow_redirects or kwargs.get("follow_redirects") is True:
            raise httpx.TransportError("redirects_disabled")
        return await super().send(request, **kwargs)


class LocalMTLSClient:
    """Constructor inputs are a protected Node-owned projection, never request data.

    trusted_egress admits only this factory's enforcing client/transport pair.
    Every TLS handshake still checks its exact peer before any HTTP bytes flow.
    """

    def __init__(self, binding: ConnectionBinding, *, ca_file, certificate_file, private_key_file):
        if type(binding) is not ConnectionBinding:
            raise ValueError("invalid_binding")
        self._binding, self._url, self._active = binding, httpx.URL(binding.base_url), True
        pem = Path(certificate_file).read_text(encoding="ascii")
        start, end = "-----BEGIN CERTIFICATE-----", "-----END CERTIFICATE-----"
        leaf = pem[pem.index(start) : pem.index(end) + len(end)]
        if (
            hashlib.sha256(ssl.PEM_cert_to_DER_cert(leaf)).hexdigest()
            != binding.client_certificate_sha256
        ):
            raise ValueError("client_certificate_pin_mismatch")
        self._ssl = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        self._ssl.minimum_version = ssl.TLSVersion.TLSv1_2
        self._ssl.load_verify_locations(cafile=str(ca_file))
        self._ssl.load_cert_chain(str(certificate_file), str(private_key_file))
        self._ssl.set_alpn_protocols(["http/1.1"])
        self._finite_transport = _Transport(
            self,
            max_connections=_FINITE_MAX_CONNECTIONS,
            max_keepalive_connections=5,
        )
        self._stream_transport = _Transport(
            self,
            max_connections=_STREAM_MAX_CONNECTIONS,
            max_keepalive_connections=0,
        )
        # Preserve the original finite-client attributes for existing consumers.
        self._transport = self._finite_transport
        self.client = _ManagedClient(
            self,
            self._finite_transport,
            transport=self._finite_transport,
            trust_env=False,
            follow_redirects=False,
            timeout=httpx.Timeout(10),
        )
        self.stream_client = _ManagedClient(
            self,
            self._stream_transport,
            transport=self._stream_transport,
            trust_env=False,
            follow_redirects=False,
            timeout=httpx.Timeout(10),
        )
        self._original_client = self.client
        self._owned_clients = (
            (self.client, self._finite_transport),
            (self.stream_client, self._stream_transport),
        )

    @property
    def binding(self):
        return self._binding

    def _require_active(self):
        if not self._active:
            raise httpx.TransportError("local_transport_revoked")

    def trusted_egress(self, connection, base, client):
        from app_security_shell.transport import TrustedEgress

        b = self.binding
        owned_transport = next(
            (transport for owned, transport in self._owned_clients if client is owned), None
        )
        if (
            not self._active
            or owned_transport is None
            or client.is_closed
            or client._transport is not owned_transport
            or client._mounts
            or connection != b.connection_id
            or base != b.base_url
        ):
            return None
        return TrustedEgress(
            b.connection_id,
            b.base_url,
            b.sender_node_id,
            b.sender_app_instance_id,
            b.recipient_node_id,
            b.recipient_app_instance_id,
            b.policy_revision,
            b.policy_digest,
            client,
        )

    def revoke(self):
        self._active = False

    async def aclose(self):
        self.revoke()
        # Close both independently owned pools even if one close fails.
        import asyncio

        outcomes = await asyncio.gather(
            *(client.aclose() for client, _transport in self._owned_clients),
            return_exceptions=True,
        )
        for outcome in outcomes:
            if isinstance(outcome, BaseException):
                raise outcome
