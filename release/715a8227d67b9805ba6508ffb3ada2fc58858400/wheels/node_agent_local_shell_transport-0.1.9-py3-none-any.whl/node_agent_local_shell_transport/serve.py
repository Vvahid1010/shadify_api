"""Fixed WSL receiver entrypoints; invoked only by their existing systemd units."""
import argparse
import os
from pathlib import Path
import ssl

import uvicorn

from .projection import ReceiverTransport, load_transport

APPS = {
    "chapary_trade_api": ("main:app", 32000),
    "chapary_api": ("main:app", 6000),
    "mizfood_api": ("main:app", 23000),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("app", choices=tuple(APPS))
    args = parser.parse_args()
    transport = load_transport()
    if not isinstance(transport, ReceiverTransport):
        raise SystemExit("local_receiver_transport_required")
    if args.app == "chapary_trade_api":
        from scripts.local_runtime_support import apply_runtime_environment
        apply_runtime_environment(
            Path("/etc/chapary-local/credentials/chapary_trade_api/runtime.json"),
            Path("/srv/Coding_space/chapary_trade_api/local_runtime/migration-state.json"),
        )
        os.environ.setdefault("DEPLOYMENT_ENVIRONMENT", "development")
    app, port = APPS[args.app]
    config = uvicorn.Config(app, host="127.0.0.1", port=port, workers=1,
                            proxy_headers=False, access_log=False, **transport.server_options())
    config.load()
    config.ssl.minimum_version = ssl.TLSVersion.TLSv1_3
    config.ssl.set_alpn_protocols(["http/1.1"])
    uvicorn.Server(config).run()


if __name__ == "__main__":
    main()
