"""Bind shared-shell admissions to the root-selected app process generation."""

from app_security_shell.binding import AppSecurityBinding


class SelectionBoundBinding(AppSecurityBinding):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Preparation/restoration is private to the process. The owner installs
        # this predicate only after an exact selection reread and atomic swap.
        self._current_selection = None

    def enable_current(self, current):
        if self._current_selection is not None or not callable(current):
            raise ValueError("managed_selection_predicate")
        self._current_selection = current

    def acquire(self):
        current = self._current_selection
        if current is not None and current() is not True:
            raise ValueError("managed_selection_changed")
        return super().acquire()

    def admit_inbound(self, selected, connection):
        self.acquire()
        return super().admit_inbound(selected, connection)
