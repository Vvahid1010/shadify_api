"""Fixed managed Nginx Unix hops; peer credentials precede every HTTP exchange.

The app owns these clients. This module never starts Nginx, edits policy, opens
TCP, accepts socket paths from requests or derives peer identity from headers.
"""

import os
import asyncio
import pwd
import socket
import stat
import struct
from dataclasses import dataclass
from pathlib import Path

import httpcore
import httpx
from uvicorn.protocols.http.h11_impl import H11Protocol

from .transport import _ManagedClient, _PinnedStream, _Transport

SENDER_SOCKET = "/run/node-agent-nginx-transport-sender/authentication.sock"
BASE = "http://node-agent-managed.invalid"
_EVIDENCE = "node_agent.managed_nginx_peer"
_HEADERS = (
    b"x-node-agent-transport-id",
    b"x-node-agent-transport-generation",
    b"x-node-agent-sender-node",
    b"x-node-agent-client-serial",
)


@dataclass(frozen=True)
class NginxUnixEndpoint:
    """Protected per-hop configuration; never populated from request headers."""
    socket_path: str
    nginx_user: str
    app_user: str
    socket_group: str
    sender_app: str
    receiver_app: str

    def __post_init__(self):
        self.local_endpoint("sender")

    def local_endpoint(self, role):
        from .local_uds import UnixEndpoint
        if role not in {"sender", "receiver"}:
            raise ValueError("managed_endpoint_role")
        return UnixEndpoint(
            self.socket_path,
            self.app_user if role == "sender" else self.nginx_user,
            self.nginx_user if role == "sender" else self.app_user,
            self.socket_group, self.sender_app, self.receiver_app,
        )

    @property
    def peer_uid(self):
        uid = pwd.getpwnam(self.nginx_user).pw_uid
        if uid <= 0:
            raise ValueError("managed_peer_account")
        return uid


def _uid():
    return pwd.getpwnam("node_agent_transport").pw_uid


def _peer(sock, endpoint=None):
    if sock is None or sock.family != socket.AF_UNIX:
        raise ValueError("managed_unix_peer_required")
    pid, uid, gid = struct.unpack("3i", sock.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
    if pid <= 0 or uid != (endpoint.peer_uid if endpoint else _uid()):
        raise ValueError("managed_nginx_peer_required")
    return pid, uid, gid


def _socket_path(endpoint=None):
    if endpoint is not None:
        from .local_uds import _socket_path as checked_path
        return checked_path(endpoint.local_endpoint("sender"))
    path = Path(SENDER_SOCKET)
    for parent in path.parents:
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid not in {0, _uid()} or info.st_mode & 0o022:
            raise ValueError("managed_socket_parent")
    info = path.lstat()
    if not stat.S_ISSOCK(info.st_mode) or info.st_uid != _uid() or info.st_mode & 0o007:
        raise ValueError("managed_socket_owner")
    return str(path)


class _UDSStream(_PinnedStream):
    async def start_tls(self, ssl_context, server_hostname=None, timeout=None):  # noqa: ASYNC109
        await self.stream.aclose()
        raise httpcore.ConnectError("managed_local_tls_disabled")


class _Backend(httpcore.AsyncNetworkBackend):
    def __init__(self, owner):
        self.owner, self.backend = owner, httpcore.AnyIOBackend()

    async def connect_tcp(self, *args, **kwargs):
        raise httpcore.ConnectError("managed_tcp_disabled")

    async def connect_unix_socket(self, path, timeout=None, socket_options=None):  # noqa: ASYNC109
        self.owner._require_active()
        if path != (self.owner.endpoint.socket_path if self.owner.endpoint else SENDER_SOCKET):
            raise httpcore.ConnectError("managed_socket_changed")
        stream = await self.backend.connect_unix_socket(_socket_path(self.owner.endpoint) if self.owner.endpoint else _socket_path(), timeout, socket_options)
        try:
            _peer(stream.get_extra_info("socket"), self.owner.endpoint) if self.owner.endpoint else _peer(stream.get_extra_info("socket"))
            self.owner._require_active()
            return _UDSStream(stream, self.owner)
        except BaseException:
            await stream.aclose()
            raise

    async def sleep(self, seconds):
        await self.backend.sleep(seconds)


class _UDSTransport(_Transport):
    def __init__(self, owner):
        self.owner = owner
        self.pool = httpcore.AsyncConnectionPool(
            network_backend=_Backend(owner),
            uds=owner.endpoint.socket_path if owner.endpoint else SENDER_SOCKET,
            http1=True,
            http2=False,
            retries=0,
            max_connections=8,
            max_keepalive_connections=0,
        )


class ManagedUDSClient:
    def __init__(self, connection, native_binding, *, current, endpoint=None):
        if endpoint is not None and type(endpoint) is not NginxUnixEndpoint:
            raise ValueError("managed_endpoint_required")
        self.endpoint = endpoint
        if not callable(current) or type(native_binding) is not tuple or len(native_binding) != 6:
            raise ValueError("managed_binding_required")
        self.connection, self.native_binding, self.current = connection, native_binding, current
        self._url, self._active, self.pid = httpx.URL(BASE), True, os.getpid()
        self._transport = self._make_transport()
        self.client = _ManagedClient(
            self,
            self._transport,
            transport=self._transport,
            trust_env=False,
            follow_redirects=False,
            timeout=httpx.Timeout(30),
        )

    def _make_transport(self):
        return _UDSTransport(self)

    def _require_active(self):
        if not self._active or os.getpid() != self.pid or self.current() is not True:
            raise httpx.TransportError("managed_selection_changed")

    def trusted_egress(self, connection, base, client):
        from app_security_shell.transport import TrustedEgress

        try:
            self._require_active()
            if (
                connection != self.connection
                or base != BASE
                or client is not self.client
                or client.is_closed
                or client._transport is not self._transport
                or client._mounts
            ):
                return None
            return TrustedEgress(connection, BASE, *self.native_binding, client)
        except Exception:
            return None

    def revoke(self):
        self._active = False

    async def aclose(self):
        self.revoke()
        await self.client.aclose()


@dataclass(frozen=True)
class _PeerEvidence:
    pid: int
    uid: int
    gid: int
    metadata: tuple[bytes, ...]
    endpoint: NginxUnixEndpoint | None = None


def trusted_ingress(
    scope,
    *,
    transport_id,
    generation,
    sender_node_id,
    client_serial,
    connection_id,
    sender_app_instance_id,
    endpoint=None,
):
    from app_security_shell.transport import TrustedPeer

    evidence = scope.get(_EVIDENCE)
    if type(evidence) is not _PeerEvidence or evidence.uid != (endpoint.peer_uid if endpoint else _uid()) or evidence.endpoint != endpoint:
        return None
    expected = tuple(
        str(value).encode("ascii")
        for value in (transport_id, generation, sender_node_id, client_serial)
    )
    if evidence.metadata != expected:
        return None
    return TrustedPeer(connection_id, sender_node_id, sender_app_instance_id)


def ingress_protocol(*, legacy_loopback_carrier=False, endpoint=None, current=None):
    """Kernel-verified Nginx peer; optional packet-3.4 loopback carrier only."""
    if type(legacy_loopback_carrier) is not bool:
        raise ValueError("invalid_legacy_carrier_option")

    if endpoint is not None and (type(endpoint) is not NginxUnixEndpoint or not callable(current) or legacy_loopback_carrier):
        raise ValueError("managed_endpoint_current_required")

    class ManagedH11Protocol(H11Protocol):
        def connection_made(self, transport):
            super().connection_made(transport)
            sock = transport.get_extra_info("socket")
            try:
                peer = _peer(sock, endpoint) if endpoint else _peer(sock)
            except (OSError, ValueError, KeyError):
                peer = None
            legacy_tcp = (
                legacy_loopback_carrier
                and sock is not None
                and sock.family == socket.AF_INET
                and sock.getsockname()[0] == "127.0.0.1"
            )
            app = self.app

            async def admitted(scope, receive, send):
                inner = dict(scope)
                inner.pop(_EVIDENCE, None)
                headers = inner.get("headers", [])
                # Fixed local readiness remains available to the root observer;
                # it never receives trusted peer evidence or a business route.
                health = (
                    inner.get("method") in {"GET", "HEAD"}
                    and inner.get("path") in {"/health", "/health/ready"}
                    and inner.get("raw_path") == inner.get("path", "").encode("ascii")
                    and not inner.get("query_string")
                )
                if health:
                    inner["headers"] = [
                        (name, value)
                        for name, value in headers
                        if not name.startswith(b"x-node-agent-")
                    ]
                    await app(inner, receive, send)
                    return
                # The retained packet-3.4 carrier authenticates its own
                # envelope. It has no native trusted-peer evidence and no
                # access to any other route on the loopback listener.
                if (
                    legacy_tcp
                    and inner.get("method") == "POST"
                    and inner.get("path") == "/api/_managed/envelope"
                    and inner.get("raw_path") == b"/api/_managed/envelope"
                    and not inner.get("query_string")
                    and not any(name.startswith(b"x-node-agent-") for name, _ in headers)
                ):
                    await app(inner, receive, send)
                    return
                values = tuple(
                    [value for name, value in headers if name == key] for key in _HEADERS
                )
                if peer is None or (endpoint is not None and current() is not True) or any(len(value) != 1 for value in values):
                    await send(
                        {
                            "type": "http.response.start",
                            "status": 403,
                            "headers": [(b"content-length", b"0")],
                        }
                    )
                    await send({"type": "http.response.body", "body": b""})
                    return
                inner[_EVIDENCE] = _PeerEvidence(*peer, tuple(value[0] for value in values), endpoint)
                # Uvicorn represents a Unix listener as (socket_path, None).
                # The shell intentionally drops Host before business dispatch;
                # give URL/path validation a fixed local authority instead.
                inner["server"] = ("node-agent-managed.invalid", 80)
                inner["headers"] = [
                    (name, value)
                    for name, value in headers
                    if not name.startswith(b"x-node-agent-")
                ]
                await app(inner, receive, send)

            self.app = admitted

    return ManagedH11Protocol


class ConfiguredSender:
    """Process-owned clients for immutable Credentials config, not a selector file."""

    def __init__(self, binding, document):
        self.binding = binding
        self.local = None
        self.components = {}
        if type(document) is dict and document.get("profile") == "channels_v1":
            if (set(document) != {"profile", "role", "profiles"} or document["role"] != "sender"
                    or type(document["profiles"]) is not list or not 1 <= len(document["profiles"]) <= 64):
                raise ValueError("configured_profiles_invalid")
            self.channels, self.clients = {}, {}
            identities, destinations = set(), set()
            for profile in document["profiles"]:
                if type(profile) is not dict or profile.get("profile") not in {"local_unix_v1", "managed_nginx"}:
                    raise ValueError("configured_nested_profile_rejected")
                component = ConfiguredSender(binding, profile)
                for connection, channel in component.channels.items():
                    if isinstance(channel, dict):
                        endpoint = channel.get("endpoint")
                        if endpoint is None:
                            raise ValueError("configured_endpoint_required")
                        identity = (channel["sender_node_id"], channel["sender_app_instance_id"], endpoint.app_user, endpoint.sender_app)
                    else:
                        endpoint = channel.endpoint
                        if endpoint is None:
                            raise ValueError("configured_endpoint_required")
                        identity = (channel.node_id, channel.sender_app_instance_id, endpoint.sender_user, endpoint.sender_app)
                    identities.add(identity)
                    if connection in self.channels or endpoint.socket_path in destinations:
                        raise ValueError("configured_channel_duplicate")
                    destinations.add(endpoint.socket_path)
                    self.channels[connection] = channel
                    self.components[connection] = component
            if len(identities) != 1 or len(self.channels) > 64:
                raise ValueError("configured_sender_identity_mismatch")
            return
        if type(document) is dict and document.get("profile") == "authentication_mixed_v1":
            if (
                set(document) != {"profile", "role", "profiles"}
                or document["role"] != "sender"
                or type(document["profiles"]) is not dict
                or set(document["profiles"]) != {"mizfood_api", "shadify_api"}
            ):
                raise ValueError("configured_mixed_transport_invalid")
            profiles = document["profiles"]
            if (
                type(profiles["mizfood_api"]) is not dict
                or profiles["mizfood_api"].get("profile") != "managed_nginx"
                or type(profiles["shadify_api"]) is not dict
                or profiles["shadify_api"].get("profile") != "local_unix_v1"
                or any(value.get("role") != "sender" for value in profiles.values())
            ):
                raise ValueError("configured_mixed_profiles_invalid")
            # Only the two existing fixed profiles compose here. Nested mixed
            # profiles, arbitrary destinations and request-selected routes deny.
            remote = ConfiguredSender(binding, profiles["mizfood_api"])
            local = ConfiguredSender(binding, profiles["shadify_api"])
            if len(local.channels) != 1:
                raise ValueError("configured_mixed_single_local_required")
            remote_id, remote_channel = next(iter(remote.channels.items()))
            local_id, local_channel = next(iter(local.channels.items()))
            if (
                remote_id == local_id
                or remote_channel["sender_node_id"] != local_channel.node_id
                or remote_channel["sender_app_instance_id"] != local_channel.sender_app_instance_id
                or remote_channel["receiver_node_id"] == local_channel.node_id
            ):
                raise ValueError("configured_mixed_identity_mismatch")
            self.components = {remote_id: remote, local_id: local}
            self.channels = {remote_id: remote_channel, local_id: local_channel}
            self.clients = {}
            return
        if type(document) is dict and document.get("profile") == "local_unix_v1":
            from .local_uds import ConfiguredLocalSender

            self.local = ConfiguredLocalSender(document)
            self.channels = self.local.channels
            self.clients = self.local.clients
            return
        self.channels = _configured_channels(document, "sender")
        self.clients = {}

    def prepare(self, connection, metadata):
        if self.components:
            return self.components[connection].prepare(connection, metadata)
        if self.local is not None:
            return self.local.prepare(connection, metadata)
        if connection not in self.channels or metadata["base_url"] != BASE:
            raise ValueError("configured_channel_mismatch")
        native = metadata["transport_binding"]
        channel = self.channels[connection]
        if (
            native[0] != channel["sender_node_id"]
            or native[1] != channel["sender_app_instance_id"]
            or native[2] != channel["receiver_node_id"]
            or ("receiver_app_instance_id" in channel and native[3] != channel["receiver_app_instance_id"])
        ):
            raise ValueError("configured_sender_identity_mismatch")
        previous = self.clients.get(connection)
        if previous is not None:
            if previous.native_binding != native:
                raise ValueError("configured_policy_changed")
            return
        client = ManagedUDSClient(
            connection, native, current=lambda: self.clients.get(connection) is client,
            endpoint=channel.get("endpoint")
        )
        self.clients[connection] = client

    def client_for(self, connection, *, stream=False):
        if self.components:
            return self.components[connection].client_for(connection, stream=stream)
        if self.local is not None:
            return self.local.client_for(connection, stream=stream)
        if stream:
            raise ValueError("managed_stream_not_supported")
        return self.clients[connection].client

    def trusted_egress(self, connection, base, client):
        if self.components:
            selected = self.components.get(connection)
            return selected.trusted_egress(connection, base, client) if selected else None
        if self.local is not None:
            return self.local.trusted_egress(connection, base, client)
        selected = self.clients.get(connection)
        return selected.trusted_egress(connection, base, client) if selected else None

    async def aclose(self):
        if self.components:
            components, self.components = self.components, {}
            targets = list({id(value): value for value in components.values()}.values())
        elif self.local is not None:
            targets = [self.local]
        else:
            clients, self.clients = self.clients, {}
            targets = list(clients.values())
        outcomes = await asyncio.gather(*(c.aclose() for c in targets), return_exceptions=True)
        for result in outcomes:
            if isinstance(result, BaseException):
                raise result


def _configured_channels(document, role):
    """Validate config-supplied peer metadata; request headers never select it."""
    import re
    from uuid import UUID

    if (
        type(document) is not dict
        or set(document) != {"profile", "role", "channels"}
        or document["profile"] != "managed_nginx"
        or document["role"] != role
        or type(document["channels"]) is not dict
        or not 1 <= len(document["channels"]) <= (64 if role == "sender" else 1)
    ):
        raise ValueError("configured_transport_invalid")
    channels = {}
    for connection, value in document["channels"].items():
        if (
            str(UUID(connection)) != connection
            or type(value) is not dict
            or set(value) - {"endpoint", "receiver_app_instance_id"}
            != {
                "transport_id",
                "generation",
                "group_revision",
                "sender_node_id",
                "receiver_node_id",
                "client_serial",
                "sender_app_instance_id",
            }
        ):
            raise ValueError("configured_channel_invalid")
        for name in (
            "transport_id",
            "sender_node_id",
            "receiver_node_id",
            "sender_app_instance_id",
        ):
            if str(UUID(value[name])) != value[name]:
                raise ValueError("configured_identity_invalid")
        for name in ("generation", "group_revision"):
            if type(value[name]) is not int or not 1 <= value[name] < 2**63:
                raise ValueError("configured_generation_invalid")
        if not re.fullmatch(r"[A-F0-9]{1,40}", value["client_serial"]):
            raise ValueError("configured_serial_invalid")
        channel = dict(value)
        if "endpoint" in value or "receiver_app_instance_id" in value:
            if not isinstance(value.get("endpoint"), dict) or str(UUID(value["receiver_app_instance_id"])) != value["receiver_app_instance_id"]:
                raise ValueError("configured_endpoint_identity_required")
            channel["endpoint"] = NginxUnixEndpoint(**value["endpoint"])
        elif len(document["channels"]) != 1:
            raise ValueError("configured_legacy_single_required")
        channels[connection] = channel
    if len(channels) > 1:
        identities = {(c["sender_node_id"], c["sender_app_instance_id"], c["endpoint"].app_user, c["endpoint"].sender_app) for c in channels.values()}
        paths = {c["endpoint"].socket_path for c in channels.values()}
        if len(identities) != 1 or len(paths) != len(channels):
            raise ValueError("configured_sender_channels_conflict")
    return channels


def install_configured_receiver(
    binding, document, policy, *, clock_bounds=None, storage_bounds=None
):
    if type(document) is dict and document.get("profile") == "local_unix_v1":
        from .local_uds import install_configured_receiver as install_local_receiver

        return install_local_receiver(
            binding, document, policy, clock_bounds=clock_bounds, storage_bounds=storage_bounds
        )
    channels = _configured_channels(document, "receiver")
    connection, channel = next(iter(channels.items()))
    endpoint = channel.get("endpoint")
    if endpoint is not None and (not callable(clock_bounds) or not callable(storage_bounds)):
        raise ValueError("configured_bounds_required")
    connections = policy["connections"]
    if len(connections) != 1 or connections[0]["connection_id"] != connection:
        raise ValueError("configured_receiver_connection_mismatch")
    sender = connections[0]["sender"]["identity"]
    recipient = connections[0]["recipient"]["identity"]
    if (
        recipient != policy["local"]
        or recipient["node_id"] != channel["receiver_node_id"]
        or recipient["app_id"] != (endpoint.receiver_app if endpoint else "mizfood_api")
        or (endpoint is not None and recipient["app_instance_id"] != channel["receiver_app_instance_id"])
        or sender["node_id"] != channel["sender_node_id"]
        or sender["app_instance_id"] != channel["sender_app_instance_id"]
        or sender["app_id"] != (endpoint.sender_app if endpoint else "authentication")
    ):
        raise ValueError("configured_receiver_identity_mismatch")

    def ingress(scope):
        return trusted_ingress(
            scope,
            connection_id=connection,
            endpoint=endpoint,
            **{
                key: channel[key]
                for key in (
                    "transport_id",
                    "generation",
                    "sender_node_id",
                    "client_serial",
                    "sender_app_instance_id",
                )
            },
        )

    binding.install_integration(
        trusted_ingress=ingress, clock_bounds=clock_bounds, storage_bounds=storage_bounds
    )
    return channel
