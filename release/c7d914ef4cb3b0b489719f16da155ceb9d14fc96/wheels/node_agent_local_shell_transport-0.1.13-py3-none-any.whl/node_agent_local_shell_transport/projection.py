"""Fixed protected WSL channel projection, independent of shell private keys."""
from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import ssl
import stat

from .ingress import PeerBinding, ingress_protocol, trusted_ingress
from .transport import ConnectionBinding, LocalMTLSClient

FILENAME = "app_security.transport.json"
MAX_BYTES = 1024 * 1024
_CONNECTION = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}")


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate_transport_field")
        result[key] = value
    return result


def _protected(path: Path, *, directory=False, private=False, owner_uid=0):
    # Reject every symbolic component, including the configured directory itself.
    if not path.is_absolute():
        raise ValueError("transport_directory_must_be_absolute")
    for component in (*reversed(path.parents), path):
        meta = component.lstat()
        if stat.S_ISLNK(meta.st_mode):
            raise ValueError("transport_symlink_rejected")
        if owner_uid == 0 and (meta.st_uid != 0 or meta.st_mode & 0o022):
            raise ValueError("transport_parent_ownership_rejected")
    metadata = path.lstat()
    valid_type = stat.S_ISDIR(metadata.st_mode) if directory else stat.S_ISREG(metadata.st_mode)
    if not valid_type or metadata.st_uid != owner_uid or metadata.st_mode & 0o022:
        raise ValueError("transport_ownership_rejected")
    if private and (metadata.st_mode & 0o007 or metadata.st_mode & 0o110
                    or (metadata.st_mode & 0o040 and metadata.st_gid != os.getegid())):
        raise ValueError("transport_private_permissions_rejected")
    return path


@dataclass(frozen=True)
class ReceiverTransport:
    peers: tuple[PeerBinding, ...]
    health_paths: tuple[str, ...]
    ca_file: Path
    certificate_file: Path
    private_key_file: Path

    def install(self, binding):
        binding.install_integration(trusted_ingress=trusted_ingress)

    def server_options(self):
        return dict(http=ingress_protocol(self.peers, self.health_paths), ws="none",
                    ssl_certfile=str(self.certificate_file), ssl_keyfile=str(self.private_key_file),
                    ssl_ca_certs=str(self.ca_file), ssl_cert_reqs=ssl.CERT_OPTIONAL,
                    ssl_version=ssl.PROTOCOL_TLS_SERVER)


@dataclass(frozen=True)
class UnixReceiverTransport:
    document: dict
    channel: object

    @property
    def endpoint(self):
        from .local_uds import LocalUnixBinding
        if isinstance(self.channel, LocalUnixBinding):
            return self.channel.endpoint
        return self.channel["endpoint"].local_endpoint("receiver")

    def install(self, binding, policy, *, clock_bounds, storage_bounds):
        from .managed_uds import install_configured_receiver
        return install_configured_receiver(binding, self.document, policy,
            clock_bounds=clock_bounds, storage_bounds=storage_bounds)

    def server_options(self):
        from .local_uds import LocalUnixBinding, ingress_protocol as local_protocol
        from .managed_uds import ingress_protocol as nginx_protocol
        if isinstance(self.channel, LocalUnixBinding):
            protocol = local_protocol(self.channel, current=lambda: True)
        else:
            protocol = nginx_protocol(endpoint=self.channel["endpoint"], current=lambda: True)
        # The immutable systemd Credentials projection lives for this process.
        return dict(http=protocol, ws="none")


def unix_receiver(document):
    from .local_uds import configured_channel
    from .managed_uds import _configured_channels
    if type(document) is not dict:
        raise ValueError("unix_projection_required")
    if document.get("profile") == "local_unix_v1":
        channel = configured_channel(document, "receiver")
        endpoint = channel.endpoint
    else:
        channel = next(iter(_configured_channels(document, "receiver").values()))
        endpoint = channel.get("endpoint")
    if endpoint is None:
        raise ValueError("unix_projection_endpoint_required")
    return UnixReceiverTransport(document, channel)


class SenderTransport:
    def __init__(self, clients):
        self.clients = {client.binding.connection_id: client for client in clients}
        if len(self.clients) != len(clients):
            raise ValueError("duplicate_transport_connection")

    def client_for(self, connection, *, stream=False):
        if type(stream) is not bool:
            raise ValueError("invalid_transport_stream_selection")
        selected = self.clients[connection]
        return selected.stream_client if stream else selected.client

    def trusted_egress(self, connection, base, client):
        selected = self.clients.get(connection)
        return selected.trusted_egress(connection, base, client) if selected else None

    def revoke(self):
        for client in self.clients.values():
            client.revoke()

    async def aclose(self):
        self.revoke()
        # Attempt every owned close even if one fails.
        import asyncio
        outcomes = await asyncio.gather(*(c.aclose() for c in self.clients.values()), return_exceptions=True)
        for outcome in outcomes:
            if isinstance(outcome, BaseException):
                raise outcome


def load_transport(directory=None, *, owner_uid=0):
    """None means no installed adapter, never permission to bypass the shell.

    Tests may explicitly name their isolated fixture owner. Production callers
    keep the root ownership default and original credential directory spelling.
    """
    original = os.environ.get("CREDENTIALS_DIRECTORY", "") if directory is None else directory
    if not original:
        return None
    root = Path(original)
    try:
        file = root / FILENAME
        # lstat rather than exists: a dangling symlink must not mean absent.
        try:
            file.lstat()
        except FileNotFoundError:
            return None
        _protected(root, directory=True, owner_uid=owner_uid)
        _protected(file, owner_uid=owner_uid)
        fd = os.open(file, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as source:
            metadata = os.fstat(source.fileno())
            if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != owner_uid or metadata.st_mode & 0o022:
                raise ValueError("transport_ownership_rejected")
            raw = source.read(MAX_BYTES + 1)
        if len(raw) > MAX_BYTES:
            raise ValueError("transport_projection_too_large")
        doc = json.loads(raw, object_pairs_hook=_unique)
        if type(doc) is dict and type(doc.get("schema_version")) is int and doc["schema_version"] == 2:
            if set(doc) != {"schema_version", "role", "transport"} or doc["role"] != "receiver":
                raise ValueError("invalid_unix_projection")
            return unix_receiver(doc["transport"])
        if type(doc) is not dict or type(doc.get("schema_version")) is not int or doc["schema_version"] != 1:
            raise ValueError("invalid_transport_schema")
        role = doc.get("role")
        allowed = {"schema_version", "role", "bindings"} | ({"health_paths"} if role == "receiver" else set())
        if set(doc) != allowed or type(doc["bindings"]) is not list or not 1 <= len(doc["bindings"]) <= 64:
            raise ValueError("invalid_transport_projection")
        tls_root = _protected(root / "app_security_tls", directory=True, owner_uid=owner_uid)
        def files(connection):
            if type(connection) is not str or not _CONNECTION.fullmatch(connection):
                raise ValueError("invalid_transport_connection")
            folder = _protected(tls_root / connection, directory=True, owner_uid=owner_uid)
            return tuple(_protected(folder / name, owner_uid=owner_uid, private=name == "private-key.pem")
                         for name in ("ca.pem", "certificate.pem", "private-key.pem"))
        if role == "receiver":
            # One Authentication peer/channel per receiver in this bounded WSL slice.
            if len(doc["bindings"]) != 1 or type(doc["health_paths"]) is not list:
                raise ValueError("invalid_receiver_projection")
            peer = PeerBinding(**doc["bindings"][0])
            paths = tuple(doc["health_paths"])
            if not paths or any(p not in ("/health", "/health/live", "/health/ready", "/api/health") for p in paths):
                raise ValueError("invalid_health_allowlist")
            ca, cert, key = files(peer.connection_id)
            return ReceiverTransport((peer,), paths, ca, cert, key)
        if role == "sender":
            records = [ConnectionBinding(**record) for record in doc["bindings"]]
            if len({r.connection_id for r in records}) != len(records):
                raise ValueError("duplicate_transport_connection")
            # Validate every file before allocating any HTTP pools.
            prepared = [(record, files(record.connection_id)) for record in records]
            clients = [LocalMTLSClient(record, ca_file=ca, certificate_file=cert, private_key_file=key)
                       for record, (ca, cert, key) in prepared]
            return SenderTransport(clients)
        raise ValueError("invalid_transport_role")
    except Exception:
        # Never include protected path, PEM or values in an outward error.
        raise ValueError("local_transport_projection_unavailable") from None


def install_projected_receiver(binding, policy=None, *, clock_bounds=None, storage_bounds=None):
    transport = load_transport()
    if transport is None:
        return
    if isinstance(transport, UnixReceiverTransport):
        if policy is None or not callable(clock_bounds) or not callable(storage_bounds):
            raise ValueError("unix_receiver_policy_bounds_required")
        return transport.install(binding, policy, clock_bounds=clock_bounds, storage_bounds=storage_bounds)
    if not isinstance(transport, ReceiverTransport):
        raise ValueError("local_receiver_transport_required")
    transport.install(binding)
