"""Fixed WSL receiver entrypoints; invoked only by their existing systemd units."""
import argparse
import os
from pathlib import Path
import ssl
import socket
import stat
import pwd
import grp
from contextlib import contextmanager

import uvicorn

from .projection import ReceiverTransport, UnixReceiverTransport, load_transport

APPS = {
    "chapary_trade_api": ("main:app", 32000),
    "chapary_api": ("main:app", 6000),
    "mizfood_api": ("main:app", 23000),
}


@contextmanager
def unix_listener(endpoint):
    """Bind only an absent socket in the provisioned directory; never replace one."""
    path = Path(endpoint.socket_path)
    uid = pwd.getpwnam(endpoint.receiver_user).pw_uid
    gid = grp.getgrnam(endpoint.socket_group).gr_gid
    if uid <= 0 or gid <= 0 or os.geteuid() != uid:
        raise ValueError("unix_listener_identity")
    for parent in path.parents:
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid not in {0, uid} or info.st_mode & 0o022:
            raise ValueError("unix_listener_parent")
    info = path.parent.lstat()
    if info.st_uid != uid or info.st_gid != gid or stat.S_IMODE(info.st_mode) != 0o750:
        raise ValueError("unix_listener_directory")
    listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    owned = None
    try:
        # bind fails on any existing file, including an existing healthy listener.
        listener.bind(str(path))
        owned = path.lstat().st_ino
        os.chown(path, -1, gid)
        os.chmod(path, 0o660)
        listener.listen(128)
        yield listener
    finally:
        listener.close()
        if owned is not None:
            try:
                if path.lstat().st_ino == owned:
                    path.unlink()
            except FileNotFoundError:
                pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("app")
    parser.add_argument("--application", default="main:app", help="Installed ASGI import, supplied by the service unit")
    args = parser.parse_args()
    transport = load_transport()
    if isinstance(transport, UnixReceiverTransport):
        if args.app != transport.endpoint.receiver_app:
            raise SystemExit("unix_receiver_app_mismatch")
        config = uvicorn.Config(args.application, workers=1, proxy_headers=False,
                                access_log=False, **transport.server_options())
        with unix_listener(transport.endpoint) as listener:
            uvicorn.Server(config).run(sockets=[listener])
        return
    if not isinstance(transport, ReceiverTransport) or args.app not in APPS:
        raise SystemExit("local_receiver_transport_required")
    if args.app == "chapary_trade_api":
        from scripts.local_runtime_support import apply_runtime_environment
        apply_runtime_environment(
            Path("/etc/chapary-local/credentials/chapary_trade_api/runtime.json"),
            Path("/srv/Coding_space/chapary_trade_api/local_runtime/migration-state.json"),
        )
        os.environ.setdefault("DEPLOYMENT_ENVIRONMENT", "development")
    app, port = APPS[args.app]
    config = uvicorn.Config(app, host="127.0.0.1", port=port, workers=1,
                            proxy_headers=False, access_log=False, **transport.server_options())
    config.load()
    config.ssl.minimum_version = ssl.TLSVersion.TLSv1_3
    config.ssl.set_alpn_protocols(["http/1.1"])
    uvicorn.Server(config).run()


if __name__ == "__main__":
    main()
